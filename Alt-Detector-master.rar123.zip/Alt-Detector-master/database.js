const { Database } = require('quickmongo');
const chalk = require('chalk')
const db = new Database('mongodb+srv://Vansh:<password>@altdetector.prlzv.mongodb.net/<dbname>?retryWrites=true&w=majority');

db.on('ready', () => {
    console.log(chalk.yellowBright(`Connected to database`))
})

module.exports = db;
