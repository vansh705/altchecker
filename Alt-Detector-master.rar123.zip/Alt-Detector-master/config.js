module.exports = {
    "token": "",//
    "prefix": "a!",//
    "COOLDOWN": "1",//
    "owner": ['638042618181320704'],
}

